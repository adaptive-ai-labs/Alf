"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Camera, PawPrintIcon as Paw } from "lucide-react"

// Sample list of dog breeds
const DOG_BREEDS = [
  "Labrador Retriever",
  "German Shepherd",
  "Golden Retriever",
  "Bulldog",
  "Beagle",
  "Poodle",
  "Rottweiler",
  "Yorkshire Terrier",
  "Boxer",
  "Dachshund",
  "Shih Tzu",
  "Siberian Husky",
  "Chihuahua",
  "Great Dane",
  "Other",
]

export default function DogUploadForm() {
  const [imagePreview, setImagePreview] = useState<string | null>(null)
  const [breed, setBreed] = useState<string>("")
  const [age, setAge] = useState<string>("adult")
  const [isUploading, setIsUploading] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      setIsUploading(true)
      const reader = new FileReader()
      reader.onloadend = () => {
        setImagePreview(reader.result as string)
        setIsUploading(false)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Here you would typically send the data to your backend
    alert(`Submitted: ${breed} (${age}) with image`)
  }

  const clearImage = () => {
    setImagePreview(null)
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  return (
    <Card className="w-full border-none shadow-lg bg-gradient-to-br from-lavender-50 to-yellow-50 rounded-xl overflow-hidden">
      <form onSubmit={handleSubmit}>
        <CardHeader className="pb-2 pt-6">
          <CardTitle className="text-center text-2xl font-bold text-lavender-700 flex items-center justify-center gap-2">
            <Paw className="h-6 w-6" />
            <span>PawProfile</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6 px-6">
          {/* Image Upload */}
          <div className="flex flex-col items-center justify-center pt-2">
            <div
              className={`
                relative w-32 h-32 rounded-full overflow-hidden 
                ${!imagePreview ? "bg-gradient-to-br from-lavender-200 to-yellow-100 border-4 border-white shadow-md" : ""}
                transition-all duration-300 hover:shadow-lg
              `}
              onClick={() => fileInputRef.current?.click()}
            >
              {imagePreview ? (
                <img
                  src={imagePreview || "/placeholder.svg"}
                  alt="Dog preview"
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <Camera className="h-10 w-10 text-lavender-500 mb-1" />
                  <p className="text-xs text-lavender-600 font-medium">Add photo</p>
                </div>
              )}

              <div className="absolute inset-0 bg-black bg-opacity-0 hover:bg-opacity-20 transition-all duration-300 flex items-center justify-center">
                {imagePreview && (
                  <Button
                    type="button"
                    variant="secondary"
                    size="sm"
                    className="opacity-0 hover:opacity-100 transition-opacity duration-300 bg-white/80 hover:bg-white text-lavender-700"
                    onClick={(e) => {
                      e.stopPropagation()
                      clearImage()
                    }}
                  >
                    Change
                  </Button>
                )}
              </div>
            </div>
            <input
              ref={fileInputRef}
              id="dog-picture"
              type="file"
              accept="image/*"
              className="hidden"
              onChange={handleFileChange}
              required
            />
            <p className="mt-3 text-sm text-lavender-600 font-medium">
              {isUploading ? "Uploading..." : imagePreview ? "Looking good!" : "Tap to add your dog's photo"}
            </p>
          </div>

          {/* Breed Selection */}
          <div className="space-y-2">
            <Label htmlFor="breed" className="text-lavender-700 font-medium">
              Breed
            </Label>
            <Select value={breed} onValueChange={setBreed} required>
              <SelectTrigger id="breed" className="bg-white/80 border-lavender-200 focus:ring-lavender-300">
                <SelectValue placeholder="What breed is your dog?" />
              </SelectTrigger>
              <SelectContent className="bg-white/95">
                {DOG_BREEDS.map((breed) => (
                  <SelectItem key={breed} value={breed}>
                    {breed}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Age Selection */}
          <div className="space-y-2">
            <Label className="text-lavender-700 font-medium">Age</Label>
            <RadioGroup value={age} onValueChange={setAge} className="flex gap-4 justify-center p-2">
              <div
                className="flex flex-col items-center space-y-1 bg-white/60 hover:bg-white/80 transition-colors rounded-lg p-3 cursor-pointer"
                onClick={() => setAge("puppy")}
              >
                <RadioGroupItem value="puppy" id="puppy" className="text-yellow-400" />
                <Label htmlFor="puppy" className="cursor-pointer text-lavender-600">
                  Puppy
                </Label>
              </div>
              <div
                className="flex flex-col items-center space-y-1 bg-white/60 hover:bg-white/80 transition-colors rounded-lg p-3 cursor-pointer"
                onClick={() => setAge("adult")}
              >
                <RadioGroupItem value="adult" id="adult" className="text-yellow-400" />
                <Label htmlFor="adult" className="cursor-pointer text-lavender-600">
                  Adult
                </Label>
              </div>
            </RadioGroup>
          </div>
        </CardContent>
        <CardFooter className="px-6 pb-6">
          <Button
            type="submit"
            className="w-full bg-gradient-to-r from-lavender-500 to-lavender-600 hover:from-lavender-600 hover:to-lavender-700 text-white font-medium py-5 rounded-xl shadow-md hover:shadow-lg transition-all duration-300"
            disabled={!imagePreview || !breed}
          >
            Create Profile
          </Button>
        </CardFooter>
      </form>
    </Card>
  )
}

